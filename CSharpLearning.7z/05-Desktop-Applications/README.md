# Desktop Applications\nThis directory focuses on creating desktop applications using either Windows Forms or WPF, data binding, control usage, and user event handling.
