# Application Architecture\nHere you will find resources on application design patterns like MVVM or MVC, dependency injection, unit testing, and version control with Git.
